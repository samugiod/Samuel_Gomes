﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Tp2
{
    class Program
    {
        //assinatura do método
        //método = tipo de retorno + nome + lista de parâmetros
        static void Main(string[] args)
        {
            MenuPrincipal();
        }

        static void MenuPrincipal()
        {
            Escrever("Gerenciador de aniversários");
            Escrever("Selecione uma das opções abaixo:");
            Escrever("1 - Pesquisar pessoas");
            Escrever("2 - Adicionar nova pessoa");
            Escrever("3 - Sair");

            string operacao = Ler();

            Console.Clear();

            switch (operacao)
            {
                case "1": PesquisarPessoas(); break;
                case "2": AdicionarPessoa(); break;
                case "3": Sair(); break;
                default:
                    Escrever("Não foi possível identificar sua operação");
                    MenuPrincipal();
                    break;
            }
        }

        static void Escrever(string texto)
        {
            Console.WriteLine(texto);
        }

        static string Ler()
        {
            return Console.ReadLine();
        }

        static void PesquisarPessoas()
        {
            foreach (var pessoa in PessoasCadastradas)
            {
                Escrever(pessoa.Id + " " + pessoa.Nome);
            }

            Escrever("Entre com o ID da pessoa para exibir os detalhes");
            int id = Convert.ToInt32(Ler());

            ExibirDetalhesDaPessoa(id);

            MenuPrincipal();
        }

        static void AdicionarPessoa()
        {
            Escrever("Entre com o nome da pessoa:");
            string nome = Ler();

            Escrever("Entre com o sobrenome da pessoa:");
            string sobrenome = Ler();

            Escrever("Entre com a data de nascimento da pessoa");
            DateTime dataDeNascimento = Convert.ToDateTime(Ler());

            Pessoa pessoa = new Pessoa();
            pessoa.Id = PessoasCadastradas.Count;
            pessoa.Nome = nome;
            pessoa.Sobrenome = sobrenome;
            pessoa.DataDeNascimento = dataDeNascimento;
            PessoasCadastradas.Add(pessoa);

            MenuPrincipal();
        }

        static List<Pessoa> PessoasCadastradas = new List<Pessoa>();

        static void Sair()
        {
            Escrever("Tchau");
        }

        static void ExibirDetalhesDaPessoa(int id)
        {
            Console.Clear();

            var pessoa = PessoasCadastradas.First(pessoa => pessoa.Id == id);
            var diasAteProximoAniversario = CalcularDiasParaOAniversario();

            Escrever(pessoa.Nome);
            Escrever($"Faltam {diasAteProximoAniversario} para o próximo aniversário");
        }

        private static int CalcularDiasParaOAniversario()
        {
            return 0;
        }
    }

    public class Pessoa
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public DateTime DataDeNascimento { get; set; }
    }
}
